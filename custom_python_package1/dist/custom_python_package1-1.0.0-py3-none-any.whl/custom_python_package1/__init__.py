def show():
    print("Hello Nikka...!")
